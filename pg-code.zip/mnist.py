import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data

def conv_layer(input, channels_in, channels_out, name='conv'):
    with tf.name_scope(name):
        w = tf.Variable(tf.truncated_normal([5, 5, channels_in, channels_out], stddev=0.1), name='W')
        b = tf.Variable(tf.constant(0.1, shape=[channels_out]), name='b')
        conv = tf.nn.conv2d(input, w, strides=[1, 1, 1, 1], padding='SAME')
        act = tf.nn.relu(conv + b)
        tf.summary.histogram('weights', w)
        tf.summary.histogram('biases', b)
        tf.summary.histogram('activations', act)
    return act

def fc_layer(input, channels_in, channels_out, name='fc'):
    with tf.name_scope(name):
        w = tf.Variable(tf.truncated_normal([channels_in, channels_out], stddev=0.1), name='W')
        b = tf.Variable(tf.constant(0.1, shape=[channels_out]), name='b')
    return tf.matmul(input, w) + b

mnist = tf.contrib.learn.datasets.mnist.read_data_sets(train_dir='data', one_hot=True)

x = tf.placeholder(tf.float32, shape=[None, 784], name='x')
y = tf.placeholder(tf.float32, shape=[None, 10], name='labels')
x_image = tf.reshape(x, [-1, 28, 28, 1])
tf.summary.image('input', x_image, 3)

conv1 = conv_layer(x_image, 1, 32, 'conv1')
pool1 = tf.nn.max_pool(conv1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

conv2 = conv_layer(pool1, 32, 64, 'conv2')
pool2 = tf.nn.max_pool(conv2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
flatterned = tf.reshape(pool2, [-1, 7 * 7 * 64])

fc1 = tf.nn.relu(fc_layer(flatterned, 7 * 7 * 64, 1024, 'fc1'))
logits = fc_layer(fc1, 1024, 10, 'fc2')

with tf.name_scope('xent'):
    cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=logits, labels=y))
    tf.summary.scalar('xent', cross_entropy)
with tf.name_scope('train'):
    train_op = tf.train.AdamOptimizer(1e-4).minimize(cross_entropy)

with tf.name_scope('accuracy'):
    correct_prediction = tf.equal(tf.argmax(logits, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    tf.summary.scalar('accuracy', accuracy)

merged_summary = tf.summary.merge_all()

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())

    writer = tf.summary.FileWriter('./tensorboard/demo3')
    writer.add_graph(sess.graph)

    for i in range(2000):
        batch = mnist.train.next_batch(100)

        if i % 5 == 0:
            s = sess.run(merged_summary, feed_dict={x: batch[0], y: batch[1]})
            writer.add_summary(s, i)
        if i % 500 == 0:
            [train_accuracy] = sess.run([accuracy], feed_dict={x: batch[0], y: batch[1]})
            print('step %d, training accuracy %g' % (i, train_accuracy))

        sess.run(train_op, feed_dict={x: batch[0], y: batch[1]})


